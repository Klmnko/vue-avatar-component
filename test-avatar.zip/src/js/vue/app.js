new Vue({
    el: '#app',
    data: {
        image: ''
    },
    methods: {
        changeImage(param) {
            this.image = param;
        }
    },
    mounted() {
    }
});